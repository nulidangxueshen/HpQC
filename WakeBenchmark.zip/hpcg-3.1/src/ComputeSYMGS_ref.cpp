
//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeSYMGS_ref.cpp

 HPCG routine
 */

#ifndef HPCG_NO_MPI
#include "ExchangeHalo.hpp"
#endif
#include "ComputeSYMGS_ref.hpp"
#include <cassert>
#include <cstring>
#include <arm_neon.h>
#include <cstdlib>

/*!
  Computes one step of symmetric Gauss-Seidel:

  Assumption about the structure of matrix A:
  - Each row 'i' of the matrix has nonzero diagonal value whose address is matrixDiagonal[i]
  - Entries in row 'i' are ordered such that:
       - lower triangular terms are stored before the diagonal element.
       - upper triangular terms are stored after the diagonal element.
       - No other assumptions are made about entry ordering.

  Symmetric Gauss-Seidel notes:
  - We use the input vector x as the RHS and start with an initial guess for y of all zeros.
  - We perform one forward sweep.  x should be initially zero on the first GS sweep, but we do not attempt to exploit this fact.
  - We then perform one back sweep.
  - For simplicity we include the diagonal contribution in the for-j loop, then correct the sum after

  @param[in] A the known system matrix
  @param[in] r the input vector
  @param[inout] x On entry, x should contain relevant values, on exit x contains the result of one symmetric GS sweep with r as the RHS.


  @warning Early versions of this kernel (Version 1.1 and earlier) had the r and x arguments in reverse order, and out of sync with other kernels.

  @return returns 0 upon success and non-zero otherwise

  @see ComputeSYMGS
*/
int ComputeSYMGS_ref( const SparseMatrix & A, const Vector & r, Vector & x) {

  assert(x.localLength==A.localNumberOfColumns); // Make sure x contain space for halo values

#ifndef HPCG_NO_MPI
  ExchangeHalo(A,x);
#endif

  const local_int_t nrow = A.localNumberOfRows;
  double ** matrixDiagonal = A.matrixDiagonal;  // An array of pointers to the diagonal entries A.matrixValues
  const double * const rv = r.values;
  double * const xv = x.values;

  double * matrixDiagonal_tmp = (double *)aligned_alloc(64, sizeof(double) * nrow);

  for (local_int_t i=0; i< nrow; i++) {
    __attribute__ ((__aligned__ (64))) const double * const currentValues = A.matrixValues[i];
    __attribute__ ((__aligned__ (64))) const local_int_t * const currentColIndices = A.mtxIndL[i];
    const int currentNumberOfNonzeros = A.nonzerosInRow[i];
    const double  currentDiagonal = 1.0 / matrixDiagonal[i][0]; // Current diagonal value
    matrixDiagonal_tmp[i] = currentDiagonal;

    double sum1 = rv[i]; // RHS value
    double sum2 = 0.0;
    double sum3 = 0.0;
    double sum4 = 0.0;
    double sum5 = 0.0;
    double sum6 = 0.0;
    double sum7 = 0.0;
    double sum8 = 0.0;

    int j=0;
    int num_cnt = currentNumberOfNonzeros - 8;

    for (; j<=num_cnt; j+=8)
    {
      sum1 -= currentValues[j  ] * xv[currentColIndices[j  ]];
      sum2 -= currentValues[j+1] * xv[currentColIndices[j+1]];
      sum3 -= currentValues[j+2] * xv[currentColIndices[j+2]];
      sum4 -= currentValues[j+3] * xv[currentColIndices[j+3]];
      sum5 -= currentValues[j+4] * xv[currentColIndices[j+4]];
      sum6 -= currentValues[j+5] * xv[currentColIndices[j+5]];
      sum7 -= currentValues[j+6] * xv[currentColIndices[j+6]];
      sum8 -= currentValues[j+7] * xv[currentColIndices[j+7]];

    }

    for (; j< currentNumberOfNonzeros; j++)
    {
      sum1 -= currentValues[j] * xv[currentColIndices[j]];
    }

    sum1 += sum2;
    sum3 += sum4;
    sum5 += sum6;
    sum7 += sum8;
    sum1 += sum3;
    sum5 += sum7;
    sum1 += sum5;

    xv[i] += sum1 * currentDiagonal;

  }

  // Now the back sweep.

  for (local_int_t i=nrow-1; i>=0; i--)
  {
    const double *          const currentValues = A.matrixValues[i];
    const local_int_t * const currentColIndices = A.mtxIndL[i];
    const int           currentNumberOfNonzeros = A.nonzerosInRow[i];
    const double                currentDiagonal = matrixDiagonal_tmp[i];

    double sum1 = rv[i]; // RHS value
    double sum2 = 0.0;
    double sum3 = 0.0;
    double sum4 = 0.0;
    double sum5 = 0.0;
    double sum6 = 0.0;
    double sum7 = 0.0;
    double sum8 = 0.0;

    int j=0;
    int num_cnt = currentNumberOfNonzeros - 8;

    for (; j<=num_cnt; j+=8)
    {
      sum1 -= currentValues[j  ] * xv[currentColIndices[j  ]];
      sum2 -= currentValues[j+1] * xv[currentColIndices[j+1]];
      sum3 -= currentValues[j+2] * xv[currentColIndices[j+2]];
      sum4 -= currentValues[j+3] * xv[currentColIndices[j+3]];
      sum5 -= currentValues[j+4] * xv[currentColIndices[j+4]];
      sum6 -= currentValues[j+5] * xv[currentColIndices[j+5]];
      sum7 -= currentValues[j+6] * xv[currentColIndices[j+6]];
      sum8 -= currentValues[j+7] * xv[currentColIndices[j+7]];

    }

    for (; j< currentNumberOfNonzeros; j++)
    {
      sum1 -= currentValues[j] * xv[currentColIndices[j]];
    }

    sum1 += sum2;
    sum3 += sum4;
    sum5 += sum6;
    sum7 += sum8;
    sum1 += sum3;
    sum5 += sum7;
    sum1 += sum5;

    xv[i] += sum1 * currentDiagonal;

  }

  free(matrixDiagonal_tmp);

  return 0;
}



















int ComputeSYMGS_ref1( const SparseMatrix & A, const Vector & r, Vector & x, double * matrixDiagonal_tmp) {

  assert(x.localLength==A.localNumberOfColumns); // Make sure x contain space for halo values

#ifndef HPCG_NO_MPI
  ExchangeHalo(A,x);
#endif

  register const local_int_t nrow = A.localNumberOfRows;
  double ** matrixDiagonal = A.matrixDiagonal;  // An array of pointers to the diagonal entries A.matrixValues
  __attribute__ ((__aligned__ (64))) const double * const rv = r.values;
  __attribute__ ((__aligned__ (64))) double * const xv = x.values;

  // float64x2_t num1, num2, num3, num4, num5, num6, num7, num8;

  for (local_int_t i=0; i< nrow; i++) {
    __attribute__ ((__aligned__ (64))) const double * const currentValues = A.matrixValues[i];
    __attribute__ ((__aligned__ (64))) const local_int_t * const currentColIndices = A.mtxIndL[i];
    register const int currentNumberOfNonzeros = A.nonzerosInRow[i];

    register double sum1 = rv[i]; // RHS value
    register double sum2 = 0.0;
    register double sum3 = 0.0;
    register double sum4 = 0.0;
    // double sum5 = 0.0;
    // double sum6 = 0.0;
    // double sum7 = 0.0;
    // double sum8 = 0.0;
    
    register int j=0;
    register int num_cnt = currentNumberOfNonzeros - 4;

    for (; j<=num_cnt; j+=4)
    {
      __builtin_prefetch(&currentColIndices[j], 0, 1);
      __builtin_prefetch(&currentValues[j], 0, 1);

      sum1 -= currentValues[j  ] * xv[currentColIndices[j  ]];
      sum2 -= currentValues[j+1] * xv[currentColIndices[j+1]];
      sum3 -= currentValues[j+2] * xv[currentColIndices[j+2]];
      sum4 -= currentValues[j+3] * xv[currentColIndices[j+3]];
      // sum5 -= currentValues[j+4] * xv[currentColIndices[j+4]];
      // sum6 -= currentValues[j+5] * xv[currentColIndices[j+5]];
      // sum7 -= currentValues[j+6] * xv[currentColIndices[j+6]];
      // sum8 -= currentValues[j+7] * xv[currentColIndices[j+7]];

    }

    for (; j< currentNumberOfNonzeros; j++)
    {
      sum1 -= currentValues[j] * xv[currentColIndices[j]];
    }

    sum1 += sum2;
    sum3 += sum4;
    // sum5 += sum6;
    // sum7 += sum8;
    sum1 += sum3;
    // sum5 += sum7;
    // sum1 += sum5;

    xv[i] += sum1 * matrixDiagonal_tmp[i];
  }

  for (local_int_t i=nrow-1; i>=0; i--)
  {
    __attribute__ ((__aligned__ (64))) const double *          const currentValues = A.matrixValues[i];
    __attribute__ ((__aligned__ (64))) const local_int_t * const currentColIndices = A.mtxIndL[i];
    register const int           currentNumberOfNonzeros = A.nonzerosInRow[i];
    register double sum1 = rv[i]; // RHS value
    register double sum2 = 0.0;
    register double sum3 = 0.0;
    register double sum4 = 0.0;
    // double sum5 = 0.0;
    // double sum6 = 0.0;
    // double sum7 = 0.0;
    // double sum8 = 0.0;

    register int j=0;
    register int num_cnt = currentNumberOfNonzeros - 4;

    for (; j<=num_cnt; j+=4)
    {
      __builtin_prefetch(&currentColIndices[j], 0, 1);
      __builtin_prefetch(&currentValues[j], 0, 1);
      
      sum1 -= currentValues[j  ] * xv[currentColIndices[j  ]];
      sum2 -= currentValues[j+1] * xv[currentColIndices[j+1]];
      sum3 -= currentValues[j+2] * xv[currentColIndices[j+2]];
      sum4 -= currentValues[j+3] * xv[currentColIndices[j+3]];
      // sum5 -= currentValues[j+4] * xv[currentColIndices[j+4]];
      // sum6 -= currentValues[j+5] * xv[currentColIndices[j+5]];
      // sum7 -= currentValues[j+6] * xv[currentColIndices[j+6]];
      // sum8 -= currentValues[j+7] * xv[currentColIndices[j+7]];
    }

    for (; j< currentNumberOfNonzeros; j++)
    {
      sum1 -= currentValues[j] * xv[currentColIndices[j]];
    }
    sum1 += sum2;
    sum3 += sum4;
    // sum5 += sum6;
    // sum7 += sum8;
    sum1 += sum3;
    // sum5 += sum7;
    // sum1 += sum5;

    xv[i] += sum1 * matrixDiagonal_tmp[i];
  }
  return 0;
}
