
//@HEADER
// ***************************************************
//
// HPCG: High Performance Conjugate Gradient Benchmark
//
// Contact:
// Michael A. Heroux ( maherou@sandia.gov)
// Jack Dongarra     (dongarra@eecs.utk.edu)
// Piotr Luszczek    (luszczek@eecs.utk.edu)
//
// ***************************************************
//@HEADER

/*!
 @file ComputeSPMV_ref.cpp

 HPCG routine
 */

#include "ComputeSPMV_ref.hpp"

#ifndef HPCG_NO_MPI
#include "ExchangeHalo.hpp"
#endif

#ifndef HPCG_NO_OPENMP
#include <omp.h>
#endif
#include <cassert>
#include <arm_neon.h>

/*!
  Routine to compute matrix vector product y = Ax where:
  Precondition: First call exchange_externals to get off-processor values of x

  This is the reference SPMV implementation.  It CANNOT be modified for the
  purposes of this benchmark.

  @param[in]  A the known system matrix
  @param[in]  x the known vector
  @param[out] y the On exit contains the result: Ax.

  @return returns 0 upon success and non-zero otherwise

  @see ComputeSPMV
*/
int ComputeSPMV_ref( const SparseMatrix & A, Vector & x, Vector & y) {

  assert(x.localLength>=A.localNumberOfColumns); // Test vector lengths
  assert(y.localLength>=A.localNumberOfRows);

#ifndef HPCG_NO_MPI
    ExchangeHalo(A,x);
#endif
  __attribute__ ((__aligned__ (64))) const double * const xv = x.values;
  __attribute__ ((__aligned__ (64))) double * const yv = y.values;
  const local_int_t nrow = A.localNumberOfRows;

#ifndef HPCG_NO_OPENMP
#pragma omp parallel for
#endif
	for ( local_int_t i = 0; i < nrow-1; i+=2 ) {
		float64x2_t sum0 = vdupq_n_f64(0.0);
		float64x2_t sum1 = vdupq_n_f64(0.0);
		if ( A.nonzerosInRow[i] == A.nonzerosInRow[i+1] ) {
			local_int_t j = 0;
			for ( j = 0; j < A.nonzerosInRow[i]-1; j+=2 ) {
				float64x2_t values0 = vld1q_f64(&A.matrixValues[i  ][j]);
				float64x2_t values1 = vld1q_f64(&A.matrixValues[i+1][j]);

				float64x2_t xvValues0 = { xv[A.mtxIndL[i  ][j]], xv[A.mtxIndL[i  ][j+1]] };
				float64x2_t xvValues1 = { xv[A.mtxIndL[i+1][j]], xv[A.mtxIndL[i+1][j+1]] };

				sum0 = vfmaq_f64(sum0, values0, xvValues0);
				sum1 = vfmaq_f64(sum1, values1, xvValues1);

			}
			double s0 = vgetq_lane_f64(sum0, 0) + vgetq_lane_f64(sum0, 1);
			double s1 = vgetq_lane_f64(sum1, 0) + vgetq_lane_f64(sum1, 1);

			if ( j < A.nonzerosInRow[i] ) {
				s0 += A.matrixValues[i  ][j] * xv[A.mtxIndL[i  ][j]];
				s1 += A.matrixValues[i+1][j] * xv[A.mtxIndL[i+1][j]];
			}
			yv[i  ] = s0;
			yv[i+1] = s1;
		} else if ( A.nonzerosInRow[i] > A.nonzerosInRow[i+1] ) {
			local_int_t j = 0;
			for ( j = 0; j < A.nonzerosInRow[i+1]-1; j+=2 ) {
				float64x2_t values0 = vld1q_f64(&A.matrixValues[i  ][j]);
				float64x2_t values1 = vld1q_f64(&A.matrixValues[i+1][j]);

				float64x2_t xvValues0 = { xv[A.mtxIndL[i  ][j]], xv[A.mtxIndL[i  ][j+1]] };
				float64x2_t xvValues1 = { xv[A.mtxIndL[i+1][j]], xv[A.mtxIndL[i+1][j+1]] };

				sum0 = vfmaq_f64(sum0, values0, xvValues0);
				sum1 = vfmaq_f64(sum1, values1, xvValues1);

			}
			double s1 = vgetq_lane_f64(sum1, 0) + vgetq_lane_f64(sum1, 1);
			if ( j < A.nonzerosInRow[i+1] ) {
				s1 += A.matrixValues[i+1][j] * xv[A.mtxIndL[i+1][j]];
			}

			for ( ; j < A.nonzerosInRow[i]-1; j+=2 ) {
				float64x2_t values0 = vld1q_f64(&A.matrixValues[i  ][j]);

				float64x2_t xvValues0 = { xv[A.mtxIndL[i  ][j]], xv[A.mtxIndL[i  ][j+1]] };

				sum0 = vfmaq_f64(sum0, values0, xvValues0);
			}
			double s0 = vgetq_lane_f64(sum0, 0) + vgetq_lane_f64(sum0, 1);
			if ( j < A.nonzerosInRow[i] ) {
				s0 += A.matrixValues[i  ][j] * xv[A.mtxIndL[i  ][j]];
			}
			yv[i  ] = s0;
			yv[i+1] = s1;
		} else { // A.nonzerosInRow[i] < A.nonzerosInRow[i+1]
			local_int_t j = 0;
			for ( j = 0; j < A.nonzerosInRow[i]-1; j+=2 ) {
				float64x2_t values0 = vld1q_f64(&A.matrixValues[i  ][j]);
				float64x2_t values1 = vld1q_f64(&A.matrixValues[i+1][j]);

				float64x2_t xvValues0 = { xv[A.mtxIndL[i  ][j]], xv[A.mtxIndL[i  ][j+1]] };
				float64x2_t xvValues1 = { xv[A.mtxIndL[i+1][j]], xv[A.mtxIndL[i+1][j+1]] };

				sum0 = vfmaq_f64(sum0, values0, xvValues0);
				sum1 = vfmaq_f64(sum1, values1, xvValues1);

			}
			double s0 = vgetq_lane_f64(sum0, 0) + vgetq_lane_f64(sum0, 1);
			if ( j < A.nonzerosInRow[i] ) {
				s0 += A.matrixValues[i][j] * xv[A.mtxIndL[i][j]];
			}

			for ( ; j < A.nonzerosInRow[i+1]-1; j+=2 ) {
				float64x2_t values1 = vld1q_f64(&A.matrixValues[i+1][j]);

				float64x2_t xvValues1 = { xv[A.mtxIndL[i+1][j]], xv[A.mtxIndL[i+1][j+1]] };

				sum1 = vfmaq_f64(sum1, values1, xvValues1);
			}
			double s1 = vgetq_lane_f64(sum1, 0) + vgetq_lane_f64(sum1, 1);
			if ( j < A.nonzerosInRow[i+1] ) {
				s1 += A.matrixValues[i+1][j] * xv[A.mtxIndL[i+1][j]];
			}
			yv[i  ] = s0;
			yv[i+1] = s1;
		}
	}
// #ifndef HPCG_NO_OPENMP
//   #pragma omp parallel for
// #endif
//   for (local_int_t i=0; i< nrow; i++)  {
//     double sum = 0.0;
//     const double * const cur_vals = A.matrixValues[i];
//     const local_int_t * const cur_inds = A.mtxIndL[i];
//     const int cur_nnz = A.nonzerosInRow[i];

//     for (int j=0; j< cur_nnz; j++)
//       sum += cur_vals[j]*xv[cur_inds[j]];
//     yv[i] = sum;
//   }
  return 0;
}
